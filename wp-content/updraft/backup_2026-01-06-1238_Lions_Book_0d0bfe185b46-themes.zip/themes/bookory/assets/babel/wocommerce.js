class Woocommerce {

}

new Woocommerce();
