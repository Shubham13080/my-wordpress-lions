class BookoryTheme {

}

$(document).ready(function () {
    new BookoryTheme();
})
