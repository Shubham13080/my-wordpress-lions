<?php
/**
 * Single page settings page
 *
 * @package HeaderFooterElementor
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div id="hfe-settings-app" class="hfe-settings-app">

</div>
