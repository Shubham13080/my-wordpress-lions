<?php
/**
 * Custom Form Builder GIF.
 *
 *  @package  PEFree/template
 */

?>

<img class="pe-cf-builder-gif" src="<?php echo esc_url( WDM_PE_PLUGIN_URL . 'assets/admin/img/form-builder.gif' ); ?>" />
