jQuery( document ).ready( function() {

    try {

        jQuery('.wp-core-ui .woocommerce-save-button').hide();
    }catch(err){}

});


